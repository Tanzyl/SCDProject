package PresentationLayer;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import DataLayer.buildFile;
public class testing extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private buildFile obj ; 

	/**
	 * Create the frame.
	 */
	public testing() {
		obj = new buildFile();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(32, 130, 214, 23);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("Upload");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ArrayList<String> row = new ArrayList();
				  String path=textField.getText(); System.out.println(path); File Folder= new
				  File(path); File[] files = Folder.listFiles();
				  for(File fXmlFile:files) {      
					  try {
					        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
					        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
					        Document doc = dBuilder.parse(fXmlFile); 
					        
					        doc.getDocumentElement().normalize(); 
					        System.out.println("Root element : " + doc.getDocumentElement().getNodeName());
					        NodeList nList = doc.getElementsByTagName("document");

					            for (int temp = 0; temp < nList.getLength(); temp++) {
					        Node nNode = nList.item(temp);
					                System.out.println("\nCurrent Element :" + nNode.getNodeName());
					        if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					        Element eElement = (Element) nNode; 
					        row.clear();
					        row.add(eElement.getElementsByTagName("title").item(0).getTextContent());
					        row.add(eElement.getElementsByTagName("author").item(0).getTextContent());
					        row.add(eElement.getElementsByTagName("section").item(0).getTextContent());
					        System.out.println("Title Name  : " + eElement.getElementsByTagName("title").item(0).getTextContent());
					        System.out.println("Author Name : " + eElement.getElementsByTagName("author").item(0).getTextContent());
					        System.out.println("Context Name : " + eElement.getElementsByTagName("section").item(0).getTextContent());
					        
					            }
					         }
					            obj.insert(row);
					       } catch (Exception e4) {
					        e4.printStackTrace();
					       }
				 String name = fXmlFile.getName(); System.out.println(name); 
				  } 
			}
		});
		btnNewButton.setBounds(84, 180, 89, 23);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("Spell Checker");
		lblNewLabel.setBackground(Color.GRAY);
		lblNewLabel.setFont(new Font("Baskerville Old Face", Font.BOLD | Font.ITALIC, 32));
		lblNewLabel.setBounds(40, 48, 206, 43);
		contentPane.add(lblNewLabel);
	}
}
