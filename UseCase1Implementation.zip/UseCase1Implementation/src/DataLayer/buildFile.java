package DataLayer;
import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
//import com.mysql.cj.xdevapi.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.mysql.cj.xdevapi.Statement;
public class buildFile {
	private static String url;
	private static String username;
	private static String password;
	private Connection con;
	private  int id ;
	public buildFile()
	{
		try
		{
			id = 1;
		url="jdbc:mysql://localhost:3306/spellchecker?useSSL=false";
		username="root";
		password=""; 
		con=DriverManager.getConnection(url, username, password);
		}
		catch(SQLException e)
		{
			System.out.println(e.toString());
		}
	}

	public void insert(ArrayList<String> row) {
		// TODO Auto-generated method stub
		String query="";
		try
		{
			query="INSERT INTO paragraphs VALUES ('"+id+"', '" +  row.get(0) + "', '"+row.get(1)+"', '"+row.get(2)+"')";
			con.createStatement().execute(query);
			id++;
		}
		catch(SQLException e)
		{
			System.out.println(query);
			System.out.println(e.toString());
		}
	}

}
